package com.itsu.chat_movil

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.java_websocket.client.WebSocketClient
import org.java_websocket.handshake.ServerHandshake
import org.json.JSONException
import org.json.JSONObject
import java.net.URI


class MainActivity : AppCompatActivity() {

    private lateinit var BtnEnviar: Button
    private lateinit var TxtChat: TextView
    private lateinit var TxtMensaje: EditText
    private var webSocketClient: WebSocketClient? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        BtnEnviar = findViewById(R.id.BtnEnviar)
        TxtChat = findViewById(R.id.TxtChat)
        TxtMensaje = findViewById(R.id.TxtMensaje)

        connectToWebSocketServer()

        BtnEnviar.setOnClickListener {
            sendMessageToServer(TxtMensaje.text.toString(), "Usuario_App")
        }
    }

    private fun connectToWebSocketServer() {
        val serverUri = URI("ws://192.168.0.16:8001") // Reemplaza con la dirección del servidor

        webSocketClient = object : WebSocketClient(serverUri) {
            override fun onOpen(handshakedata: ServerHandshake) {
                // Manejar la conexión exitosa con el servidor (se llama en el hilo de fondo)
                runOnUiThread {
                    TxtChat.text = "Conexión establecida con el servidor."
                }
            }

            override fun onMessage(message: String) {
                // Manejar mensajes recibidos del servidor (se llama en el hilo de fondo)
                runOnUiThread {
                    // Analiza el mensaje JSON para obtener nombre y mensaje
                    // Asumiendo que el servidor envía un JSON con 'nombre' y 'mensaje'
                    val data = try {
                        JSONObject(message)
                    } catch (e: JSONException) {
                        JSONObject()
                    }

                    val nombre = data.optString("nombre", "Usuario")
                    val mensaje = data.optString("mensaje", "")

                    // Muestra el mensaje en el TextView
                    TxtChat.append("\n$nombre: $mensaje")
                    TxtMensaje.text.clear()
                }
            }

            override fun onClose(code: Int, reason: String, remote: Boolean) {
                // Manejar la desconexión del servidor (se llama en el hilo de fondo)
                runOnUiThread {
                    TxtChat.text = "Desconectado del servidor."
                }
            }

            override fun onError(ex: Exception) {
                // Manejar errores (se llama en el hilo de fondo)
                runOnUiThread {
                    TxtChat.text = "Error de conexión: ${ex.message}"
                }
            }
        }

        webSocketClient?.connect()
    }

    private fun sendMessageToServer(mensaje: String, nombre: String) {
        // Enviar un mensaje al servidor en formato JSON
        val jsonMessage = JSONObject()
        jsonMessage.put("nombre", nombre)
        jsonMessage.put("mensaje", mensaje)
        webSocketClient?.send(jsonMessage.toString())
    }

    override fun onDestroy() {
        super.onDestroy()
        webSocketClient?.close()
    }
}